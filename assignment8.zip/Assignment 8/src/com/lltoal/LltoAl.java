package com.lltoal;
import java.util.*;
public class LltoAl {
List<Integer>ll;
public LltoAl() {
	ll=new LinkedList<>();
	ll.add(1);
	ll.add(2);
	ll.add(3);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LltoAl t=new LltoAl();
		t.convert();
		

	}
	public void convert() {
		ArrayList<Integer>l=new ArrayList<>(ll);
		System.out.println("Linked List is now ArrayList");
		for(int i:l)
			System.out.println(i);
	}

}
