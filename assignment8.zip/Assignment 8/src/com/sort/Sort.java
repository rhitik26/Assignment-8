package com.sort;
import java.util.*;
public class Sort {
	List<Integer>arr;
	public Sort() {
		arr=new ArrayList<>();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a;
		Sort m=new Sort();
		do {
			System.out.println("1:Add");
			System.out.println("2:Sort");
			System.out.println("3:exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter element");
				a=sc.nextInt();
				m.add(a);
			break;
			case 2:m.sot();
			break;
			case 3:System.out.println("Exiting.....");
			System.exit(0);
			}
		}while(true);
	}
	public void add(int a) {
		arr.add(a);
	}
	public void sot() {
		Collections.sort(arr);
		for (int a:arr)
			System.out.println(a);
	}

}
