package com.copy;

import java.util.TreeMap;

public class Copy {
	TreeMap<Integer,String> tr=new TreeMap<>();
	TreeMap<Integer,String> tr2=new TreeMap<>();
	public Copy() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
		tr2.put(6, "Rajesh");
		tr2.put(7, "Rahul");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Copy c=new Copy();
		c.cat();

	}
	public void cat() {
		tr.putAll(tr2);
		System.out.println("After copying"+tr);
		
	}

}
