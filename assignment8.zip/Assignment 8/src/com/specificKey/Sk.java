package com.specificKey;

import java.util.Scanner;
import java.util.TreeMap;

public class Sk {
	TreeMap<Integer,String> tr=new TreeMap<>();
	public Sk() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter index");
		int i=sc.nextInt();
		Sk s=new Sk();
		s.disp(i);

	}
	public void disp(int i) {
		System.out.println("Key(s): " + tr.headMap(i));
	}

}
