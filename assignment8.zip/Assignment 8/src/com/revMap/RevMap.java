package com.revMap;

import java.util.TreeMap;

public class RevMap {
	TreeMap<Integer,String> tr=new TreeMap<>();
	public RevMap() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RevMap rm=new RevMap();
		rm.disp();

	}
	public void disp() {
		System.out.println("Reverse order view of the keys: " + tr.descendingKeySet());
	}

}
