package com.shuffle;
import java.util.*;
public class Shuffle {
List<Integer>arr;
public Shuffle() {
	arr=new ArrayList<>();
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int a;
	Shuffle s=new Shuffle();
	do {
		System.out.println("!:ADD");
		System.out.println("2:Shuffle");
		System.out.println("3:Exit");
		int ch=sc.nextInt();
		switch(ch) {
		case 1:System.out.println("enter element");
		a=sc.nextInt();
		s.add(a);
		break;
		case 2:s.shu();
		break;
		case 3:System.out.println("Exiting.....");
		System.exit(0);
		break;
		}
	}while(true);
}
public void add(int a) {
	arr.add(a);
}
public void shu() {
	System.out.println("Before Shuffle");
	for(int a:arr)
		System.out.println(a);
	System.out.println("After Shuffle....");
	Collections.shuffle(arr);
	for(int a:arr) {
		System.out.println(a);
	}
}
}
