package com.map;

import java.util.TreeMap;

public class Map {
	TreeMap<Integer,String> tr=new TreeMap<>();
	public Map() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		 System.out.println("Checking the entry for 1: ");
//	        System.out.println("Value is: " + tr.floorEntry(1));
//	        System.out.println("Checking the entry for 3: ");
//	        System.out.println("Value is: " + tr.floorEntry(3));
		Map m=new Map();
		m.disp();
	}
	public void disp() {
		 System.out.println("Checking the entry for 1: ");
	        System.out.println("Value is: " + tr.floorEntry(1));
	        System.out.println("Checking the entry for 3: ");
	        System.out.println("Value is: " + tr.floorEntry(3));
	}

}
