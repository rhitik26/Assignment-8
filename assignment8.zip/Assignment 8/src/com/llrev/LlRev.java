
package com.llrev;
import java.util.*;
public class LlRev {
List<Integer>arr;
public LlRev() {
	arr=new ArrayList<>();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		LlRev r=new LlRev();
		int a;
		do {
			System.out.println("1:Add");
			System.out.println("2:Reverse");
			System.out.println("3:exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("Enter element");
			a=sc.nextInt();
			r.add(a);
			break;
			case 2:
				r.rev();
				break;
			case 3:
				System.out.println("Exiting.....");
				System.exit(0);
				break;
			}
		}while(true);

	}
	public void add(int a) {
		arr.add(a);
	}
	public void rev() {
		System.out.println("Before Reverse");
		for(int a:arr)
			System.out.println(a);
		System.out.println("After reverse");
		Collections.reverse(arr);
		for(int a:arr)
			System.out.println(a);
	}

}
