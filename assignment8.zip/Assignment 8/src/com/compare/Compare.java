package com.compare;
import java.util.*;
public class Compare {
List<Integer>arr1;
List<Integer>arr2;
public Compare() {
	arr1=new ArrayList<>();
	arr2=new ArrayList<>();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Compare c=new Compare();
		int a1,a2;
		do {
			System.out.println("1:Add");
			System.out.println("2:Compare");
			System.out.println("3:Exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("To list1");
			a1=sc.nextInt();
			c.add1(a1);
			System.out.println("to list2");
			a2=sc.nextInt();
			c.add2(a2);
			break;
			case 2:
				c.compare();
				break;
			case 3:
				System.out.println("EXITING....");
				System.exit(0);
				break;
			}
		}while(true);
	}
	public void add1(int a1) {
		arr1.add(a1);
	}
	public void add2(int a2) {
		arr2.add(a2);
	}
	public void compare()
	{
		boolean isEqual=arr1.equals(arr2);
		if(isEqual==true)
			System.out.println("Equal");
		else
			System.out.println("Not equal");
	}

}
