package com.retreive;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Retreive {
	List<Integer> arr;
	public Retreive() {
		arr=new ArrayList<>();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Retreive r=new Retreive();
		int a,i,ch;
		do {
			System.out.println("1:add");
			System.out.println("2:Retreive");
			System.out.println("3:exit");
			ch=s.nextInt();
			
			switch(ch) {
			case 1:
				System.out.println("enter element");
				a=s.nextInt();
				r.add(a);
				break;
			case 2:System.out.println("enter index");
			i=s.nextInt();
			r.search(i);
			break;
			case 3:System.exit(0);
			}
		}while(true);

	}
	public void add(int a) {
		arr.add(a);
		for(int ar:arr)
			System.out.println(ar);
	}
	public void search(int i) {
		System.out.println(arr.get(i));
	}

}
