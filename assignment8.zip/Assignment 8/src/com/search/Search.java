package com.search;

import java.util.*;

public class Search {
	List<Integer>arr;
	public Search() {
		arr=new ArrayList<>();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int ch,a,s;
		Search m=new Search();
		do {
			System.out.println("1:Add");
			System.out.println("2:Search");
			System.out.println("3:exit");
			ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("Enter element");
			a=sc.nextInt();
			//arr.add(a);
			m.add(a);
			break;
			case 2:
				System.out.println("Enter element to be searched");
				s=sc.nextInt();
				m.search1(s);
				break;
			case 3:
//				op=1;
//				System.out.println("Exit");
				System.exit(0);
			}
		}while(true);
		

	}
	public void add(int a) {
		arr.add(a);
	}
	public void search1(int s) {
		if(arr.contains(s))
			System.out.println(arr.indexOf(s));
	}

}
