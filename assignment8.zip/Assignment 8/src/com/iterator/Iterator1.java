package com.iterator;
import java.util.*;
public class Iterator1 {
List<Integer> ll;
public Iterator1() {
	ll=new LinkedList<>();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Iterator1 it=new Iterator1();
		int a,i;
		do {
			System.out.println("1:Add");
			System.out.println("2:Iterate");
			System.out.println("3:EXIT");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("Enter element");
			a=sc.nextInt();
			it.add(a);
			break;
			case 2:System.out.println("Enter index from where to iterate");
			i=sc.nextInt();
			it.iterate(i);
			break;
			case 3:System.out.println("exiting...");
			System.exit(0);
			break;
			}
		}while(true);
	}
	public void add(int a) {
		ll.add(a);
	}
	public void iterate(int i) {
		Iterator p=ll.listIterator(i);
		while(p.hasNext()) {
			System.out.println(p.next());
		}
	}

}
