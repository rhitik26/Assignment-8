package com.append;
import java.util.*;
public class Append {
	List<Integer> ll;
public Append() {
	ll=new LinkedList<>();
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a;
		Append ap=new Append();
		do {
			System.out.println("1:Add");
			System.out.println("2:exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("enter element");
			a=sc.nextInt();
			ap.add(a);
			break;
			case 2:
				System.out.println("Exiting....");
				System.exit(0);
				break;
			}
		}while(true);

	}
	public void add(int a) {
		ll.add(a);
		for(int ar:ll) {
			System.out.println(ar);
		}
	}

}
