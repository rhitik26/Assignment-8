package com.searchkey;
import java.util.*;
import java.util.TreeMap;

public class SearchKey {
	TreeMap<Integer,String> tr=new TreeMap<>();
	public SearchKey() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		SearchKey s=new SearchKey();
		System.out.println("enter index");
		int i=sc.nextInt();
		s.search(i);
	}
	public void search(int i) {
		if(tr.containsKey(i))
			System.out.println("value is"+tr.floorEntry(i));
		else
			System.out.println("Not Found");
	}

}
