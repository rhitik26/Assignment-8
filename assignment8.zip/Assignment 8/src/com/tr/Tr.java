package com.tr;

import java.util.Map;
import java.util.TreeMap;

public class Tr {
TreeMap<Integer,String> tr=new TreeMap<>();
public Tr() {
	tr.put(1, "Rhitik");
	tr.put(2, "yash");
	tr.put(3, "Tejas");
	tr.put(4, "pandey");
	tr.put(5, "rishabh");
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tr t=new Tr();
		t.disp();

	}
	public void disp() {
		for(Map.Entry<Integer, String>e:tr.entrySet()) {
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}

}
