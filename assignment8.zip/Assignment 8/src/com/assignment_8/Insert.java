package com.assignment_8;
//package com.collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//import com.collections.Main;
public class Insert {
	List<Integer>arr;
	public Insert() {
		arr=new ArrayList<>();
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		Insert m=new Insert();
		int op=0,a;
		do {
			System.out.println("enter element to add");
			a=s.nextInt();
			m.add(a);
			m.disp();
			System.out.println("press 1 to exit and 0 to continue");
			op=s.nextInt();
		}while(op!=1);
//		if(op==1) {
//			System.exit(0);
//		}
		// TODO Auto-generated method stub

	}
	public void add(int a) {
		//Insert m=new Insert();
		arr.add(0,a);
		System.out.println("Size of list is:"+arr.size());
		//m.disp();
	}
	public void disp() {
		for(int a:arr) {
			System.out.println(a);
		}
	}
	

}
