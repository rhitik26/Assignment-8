package com.first;

import java.util.LinkedList;
import java.util.List;

public class First {
	LinkedList <Integer> ll=new LinkedList<>();

	public First() {
		
		ll.add(1);
		ll.add(20);
		ll.add(39);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		First f = new First();
		f.disp();
	}

	public void disp() {
		System.out.println("Removed item:" + ll.pop());
		System.out.println("After removing....");
		for(int i:ll)
			System.out.println(i);
	}

}
