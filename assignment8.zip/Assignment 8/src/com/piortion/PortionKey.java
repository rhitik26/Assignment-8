package com.piortion;

import java.util.Scanner;
import java.util.SortedMap;
import java.util.TreeMap;

public class PortionKey {
	TreeMap<Integer,String> tr=new TreeMap<>();
	 SortedMap< Integer, String > tr3 = new TreeMap <> ();
	public PortionKey() {
		tr.put(1, "Rhitik");
		tr.put(2, "yash");
		tr.put(3, "Tejas");
		tr.put(4, "pandey");
		tr.put(5, "rishabh");
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter first index");
		int i=sc.nextInt();
		System.out.println("enter second index");
		int j=sc.nextInt();
		PortionKey p=new PortionKey();
		p.disp(i,j);
	}
	public void disp(int i,int j) {
		tr3=tr.subMap(i, j);
		System.out.println(tr3);
	}
}
