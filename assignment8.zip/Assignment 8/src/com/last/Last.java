package com.last;
import java.util.*;
import java.io.*;
public class Last {
	LinkedList ll=new LinkedList<>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Last l=new Last();
		String a;
		do {
			System.out.println("1:add");
			System.out.println("2:last element");
			System.out.println("3:exit");
			int ch=sc.nextInt();
			switch(ch) {
			case 1:System.out.println("enter element");
			a=sc.next();
			l.add(a);
			break;
			case 2:l.gl();
			break;
			case 3:System.exit(0);
			break;
			}
		}while(true);

	}
	public void add(String a) {
		ll.add(a);
	}
	public void gl() {
		Object x=ll.getLast();
		System.out.println("Last item is:"+x);
	}

}
